const {execSync, exec} = require('child_process');


function mjrToMp4(mjr, outputVideo, sw, sh) {
    console.log('mjrToMp4', mjr);
    let h = header(mjr);
    let cmd;
    if(!h){
        // 关闭摄像头入会时，录制生成的视频流文件是非法的，在此，生成一个黑屏的视频文件，方便后续处理
        cmd = `ffmpeg -f lavfi -i color=s=${sw}x${sh}:r=25:c='#000000':d=0 ${outputVideo}`
        execSync(cmd);
        return
    } else if (h.c === 'vp8') {
        console.log('mj4 to webp', mjr);
        let webm = outputVideo.replace('.mp4', '.webm');
        cmd = `janus-pp-rec  ${mjr} ${webm}`
        execSync(cmd);
        cmd = `ffmpeg -i ${webm} ${outputVideo}.mp4`
        execSync(cmd);
    } else {
        cmd = `janus-pp-rec  ${mjr} ${outputVideo}.mp4`
        execSync(cmd);
    }

    // rotate
    let transpose = '';
    // cmd = `ffprobe -v error -select_streams v -show_entries stream=width,height -of csv=p=0:s=x ${outputVideo}.mp4`
    // let stdout = execSync(cmd);
    // let str = stdout.toString();
    // let dimension = str.split('x');
    // width > height
    // "x": {"13": "urn:3gpp:video-orientation"}
    // 好像不准，windows 和 移动端都是这个值，但是 windows 端视频是正确的
    // if (h.x['13'] && dimension[0] > dimension[1]) {
    if (h.x['13'] === 'urn:3gpp:video-orientation') {
        console.log('to rotate')
        // fyi: https://www.baeldung.com/linux/ffmpeg-rotate-video
        // 逆时针旋转 90 度
        transpose = 'transpose=2,'
    }

    // scale down
    cmd = `ffmpeg  -v error -stats -i ${outputVideo}.mp4 -vf "${transpose}scale=${sw}:${sh}:force_original_aspect_ratio=1,pad=${sw}:${sh}:(ow-iw)/2:(oh-ih)/2" -max_muxing_queue_size 9999999 ${outputVideo}`
    execSync(cmd);
}

function mjrToOpus(mjr, outputAudio) {
    console.log('mjrToOpus', mjr);
    let cmd = `janus-pp-rec  ${mjr} ${outputAudio}`
    execSync(cmd);
}

function mergeAudioAndVideo(inputVideo, inputAudio, outputVideo) {
    console.log('mergeAudioAndVideo', inputVideo, inputAudio, outputVideo)
    let cmd;
    if (inputAudio) {
        cmd = `ffmpeg -i ${inputVideo} -i ${inputAudio} -c:v copy -c:a aac ${outputVideo}`
    } else {
        // 屏幕共享没有音频流，这儿加一个静音的音频流，方便后面处理
        console.warn('input audio is undefined, maybe input video is screen sharing, add silent audio')
        cmd = `ffmpeg -f lavfi -i anullsrc=channel_layout=stereo:sample_rate=44100 -i ${inputVideo} -c:v copy -c:a aac -shortest ${outputVideo}`
    }
    execSync(cmd)
}


function padEnd(inputVideo, duration, outVideo, sw, sh) {
    console.log('padEnd', inputVideo, outVideo, duration);
    //let cmd = `ffmpeg -i ${inputVideo} -filter_complex "[0:v]tpad=stop_duration=${duration}[v];[0:a]apad=pad_dur=${duration}[a]" -map "[v]" -map "[a]" ${outVideo}`
    let cmd = `ffmpeg -i ${inputVideo} -vf "color=c=black:size=${sw}x${sh}:duration=${duration}[s];[0:v][s]concat" -c:v libx264 -c:a copy ${outVideo}`
    return execSync(cmd);
}

function padStart(inputVideo, duration, outVideo, sw, sh) {
    duration = Math.round(duration);
    console.log('padStart', inputVideo, outVideo, duration);
    let tmpFile = inputVideo + '.mp4';
    // let padCmd = `ffmpeg -i ${inputVideo} -video_track_timescale 90k -filter_complex "tpad=start_duration=${duration}" ${tmpFile} `;
    // execSync(padCmd);
    let cmd = `ffmpeg -i ${inputVideo} -vf "color=c=black:size=${sw}x${sh}:duration=${duration}[s];[s][0:v]concat" -c:v libx264 -c:a copy ${tmpFile}`
    execSync(cmd);
    let delayCmd = `ffmpeg -i ${tmpFile} -af "adelay=${duration}s" ${outVideo}`;
    execSync(delayCmd);
    execSync(`rm -f ${tmpFile}`);

    // // test
    // let cmd = `ffmpeg -i ${inputVideo} -filter_complex "[0:v]tpad=start_duration=${duration}[v];[0:a]adelay=${duration}[a]" -map "[v]" -map "[a]" ${outVideo}`;
    // execSync(cmd);

}

function concat(outputVideo, ...videos) {
    if (videos.length < 1) {
        return;
    }
    console.log('concat', outputVideo, videos);
    let cf = '';
    videos.forEach(video => {
        cf += `file ${video} \n`
        // cf += `duration ${duration(video)} \n`
    })
    execSync(`echo "${cf}" > list.txt`);
    //let concatCmd = `ffmpeg -f concat -i list.txt -c:v copy -c:a copy ${outputVideo}`
    let concatCmd = `ffmpeg -f concat -i list.txt -max_muxing_queue_size 9999999 -c:v h264 -c:a aac ${outputVideo}`
    execSync(concatCmd);
    execSync(`rm -f list.txt`);
}

function duration(inputVideo) {
    let cmd = `ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 ${inputVideo}`;
    let stdout = execSync(cmd);
    console.log('duration: ', inputVideo, stdout.toString());
    return stdout.toString();
}

function header(inputVideo) {
    let cmd = `janus-pp-rec -j ${inputVideo}`
    let stdout = execSync(cmd);
    let str = stdout.toString();
    if (str) {
        let json = JSON.parse(str);
        return json;
    }
    return undefined;
}

function size(inputVideo) {
    // TODO
}

function resolution(inputVideo) {
    let cmd = `ffprobe -v error -select_streams v:0 -show_entries stream=width,height -of csv=s=x:p=0 ${inputVideo}`
    let stdout = execSync(cmd);
    console.log('resolution: ', inputVideo, stdout.toString());
    return stdout.toString();
}

function maxDuration(...videos) {
    let md = 0;
    videos.forEach(v => {
        let d = duration(v)
        if (d > md) {
            md = d;
        }
    })
    console.log('maxDuration', md);
    return md;
}

function parseRecordFileName(fileName) {
    let arr = fileName.split('-');
    if (arr.length > 7) {
        let tmp = arr.slice(0, 3);
        tmp = tmp.concat(arr.slice(arr.length - 3))
        tmp.splice(3, 0, arr.slice(3, arr.length - 3).join('-'))
        return tmp;
    } else {
        return arr;
    }
}

function listBigVideoMjrs() {
    let cmd = 'ls videoroom*-video-*.mjr';
    let stdout = execSync(cmd);
    let files = stdout.toString().split('\n').filter(f => f.startsWith('videoroom'))
    files = files.filter(f => {
        if (f.indexOf('user-screen') > 0) {
            // 屏幕共享，video-0 是大流
            return f.indexOf('video-0') > 0;
        } else {
            // 普通视频流，video-1 是大流
            return f.indexOf('video-1') > 0;
        }
    });
    // files = files.filter(f => {
    //     let h = header(f);
    //     console.warn('ignore file ', f)
    //     return h !== undefined;
    // })
    console.log('listBigVideoMjrs: \n', files);
    return files;
}

function listAudioMjrs() {
    let cmd = 'ls videoroom*-audio-0.mjr';
    let stdout = execSync(cmd);
    let files = stdout.toString().split('\n').filter(f => f.startsWith('videoroom'))
    console.log('listAudioMjrs: \n', files);
    return files;
}

// FYI https://www.jimby.name/techbits/recent/xstack/
function merge(outputVideo, w, h, ...videos) {
    let input = () => {
        let tmp = '';
        videos.forEach(v => {
            tmp += '-i ' + v + '\\';
        })
        return tmp;
    }
}

function decodeAndMerge() {
    let bigVideoMjrs = listBigVideoMjrs();
    let startTimestamp = bigVideoMjrs
        .map(f => parseRecordFileName(f)[4])
        .reduce((previousValue, currentValue, currentIndex, array) => {
            return currentValue < previousValue ? currentValue : previousValue;
        });
    console.log('conference start timestamp', startTimestamp)

    let tmpDir = 'tmp';
    execSync(`rm -rf ${tmpDir}`)
    execSync(`mkdir ${tmpDir}`)

    let sw = 1440;
    let sh = 1080;
    if (bigVideoMjrs.length <= 4) {
        sw = 720;
        sh = 640;
    } else if (bigVideoMjrs.length <= 9) {
        sw = 480;
        sh = 360;
    } else if (bigVideoMjrs.length <= 16) {
        sw = 360;
        sh = 270;
    } else {
        sw = 280;
        sh = 200;
    }
    bigVideoMjrs.forEach(f => {
        mjrToMp4(f, `${tmpDir}/${f}.mp4`, sw, sh)
        // TODO 如果需要在视频上加上水印等，可以在此操作上一步生成的视频文件
    })

    let audioMjrs = listAudioMjrs();
    audioMjrs.forEach(f => {
        mjrToOpus(f, `${tmpDir}/${f}.opus`)
    })

    // video file 和 audio file 是一一对应的
    let tmpMergedVideoDir = 'tmpMergedVideo';
    execSync(`rm -rf ${tmpMergedVideoDir}`)
    execSync(`mkdir ${tmpMergedVideoDir}`)

    let userVideoMap = new Map();

    bigVideoMjrs.forEach(f => {
        let varr = parseRecordFileName(f)
        let prefix = varr[0] + '-' + varr[1] + '-' + varr[2] + '-' + varr[3];
        let audioFiles = audioMjrs.filter(f => f.startsWith(prefix));
        let audioFile;
        if (audioFiles.length === 1) {
            audioFile = audioFiles[0];
        } else {
            // 找和视频时间最接近的相同用户的音频文件
            // 时间在一秒以内
            for (const af of audioFiles) {
                let aarr = parseRecordFileName(af)
                if (Math.abs(varr[4] - aarr[4]) < 100 * 1000) {
                    audioFile = af;
                    break
                }
            }
        }
        mergeAudioAndVideo(`${tmpDir}/${f}.mp4`, audioFile ? `${tmpDir}/${audioFile}.opus` : null, `${tmpMergedVideoDir}/${f}.mp4`)

        let userId = varr[3];
        let userVideos = userVideoMap.get(userId);
        if (!userVideos) {
            userVideos = [`${f}.mp4`];
        } else {
            userVideos.push(`${f}.mp4`)
        }
        userVideoMap.set(userId, userVideos);
    })

    //execSync(`rm -rf ${tmpDir}`)

    // 保存经过时间对齐后的所有参与者会议录制视频
    const tmpPaddedVideoDir = 'tmpPaddedVideo';
    execSync(`rm -rf ${tmpPaddedVideoDir}`)
    execSync(`mkdir ${tmpPaddedVideoDir}`)

    // 保存某个参与者多次进出会议产生的录制视频
    const tmpUserPaddedVideoDir = 'tmpUserPaddedVideo';
    execSync(`rm -rf ${tmpUserPaddedVideoDir}`)
    execSync(`mkdir ${tmpUserPaddedVideoDir}`)

    // pad
    userVideoMap.forEach((videos, userId) => {
        console.log('user videos', videos)
        if (videos.length > 1) {

            let sortedVideos = videos.sort((v1, v2) => {
                let ts1 = parseRecordFileName(v1)[4];
                let ts2 = parseRecordFileName(v2)[4];
                return ts1 > ts2;
            })
            let ts = parseRecordFileName(sortedVideos[0])[4];
            let paddedUserVideos = [];
            padStart(`${tmpMergedVideoDir}/${sortedVideos[0]}`, (ts - startTimestamp) / 1000 / 1000, `${tmpUserPaddedVideoDir}/${sortedVideos[0]}`, sw, sh)
            paddedUserVideos.push(`${tmpUserPaddedVideoDir}/${sortedVideos[0]}`)
            for (let i = 1; i < sortedVideos.length; i++) {
                let preTS = parseRecordFileName(sortedVideos[i - 1])[4];
                let curTS = parseRecordFileName(sortedVideos[i])[4];
                padStart(`${tmpMergedVideoDir}/${sortedVideos[i]}`, (curTS - preTS) / 1000 / 1000, `${tmpUserPaddedVideoDir}/${sortedVideos[i]}`, sw, sh)
                paddedUserVideos.push(`${tmpUserPaddedVideoDir}/${sortedVideos[i]}`)
            }
            // 同一用户的多段视频拼接
            concat(`${tmpPaddedVideoDir}/${sortedVideos[0]}`, ...paddedUserVideos);

        } else {
            let ts = parseRecordFileName(videos[0])[4];
            padStart(`${tmpMergedVideoDir}/${videos[0]}`, (ts - startTimestamp) / 1000 / 1000, `${tmpPaddedVideoDir}/${videos[0]}`, sw, sh)
        }
    })

    // padEnd，所有视频长度统一
    // 好像没啥用了，先注释了

    // let cmd = `ls ${tmpPaddedVideoDir}`;
    // let stdout = execSync(cmd);
    // let files = stdout.toString().split('\n').filter(f => f.indexOf('.mp4') > 0)
    // let maxDuration = 0;
    // let videoDurations = {};
    // files.forEach(f => {
    //     cmd = `ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 ${tmpPaddedVideoDir}/${f}`
    //     let ds = execSync(cmd);
    //     let duration = Math.round(Number(ds));
    //     videoDurations[f] = duration;
    //     if (duration > maxDuration) {
    //         maxDuration = duration;
    //     }
    // })
    // console.log('maxDuration', maxDuration);
    // files.forEach(f => {
    //     let duration = videoDurations[f];
    //     if (duration < maxDuration) {
    //         padEnd(`${tmpPaddedVideoDir}/${f}`, maxDuration - duration, `${tmpPaddedVideoDir}/${f}.mp4`, sw, sh);
    //         cmd = `rm -f ${tmpPaddedVideoDir}/${f}`
    //         execSync(cmd)
    //     }
    // })

    // grid layout

    // const tmpPaddedVideoDir = 'tmpPaddedVideo';
    cmd = `ls ${tmpPaddedVideoDir}/*.mp4`;
    stdout = execSync(cmd);
    files = stdout.toString().split('\n').filter(f => f.endsWith('.mp4'));
    console.log('tmpPaddedVideo: \n', files);

    let matrixSize = 0;
    if (files.length <= 4) {
        matrixSize = 2;
    } else if (files.length <= 9) {
        matrixSize = 3;
    } else if (files.length <= 16) {
        matrixSize = 4;
    } else if (files.length <= 25) {
        matrixSize = 5
    }

    let outputFile = files[0].split('/')[1].split('-').slice(0, 2).join('-');
    outputFile += '.mp4'
    execSync('rm -f merge.sh')
    execSync(`rm -f ${outputFile}`)

    if(files.length < 2){
        execSync(`mv ${files[0]} ${outputFile}`)
        return;
    }

    execSync(`perl creatematrix.pl ${matrixSize} 'row' ${outputFile} ${sw}x${sh} > merge.sh`)
    execSync('chmod u+x merge.sh')
    console.log(execSync('cat merge.sh').toString())
    console.log('merge ...')
    execSync('./merge.sh')

}

decodeAndMerge()
