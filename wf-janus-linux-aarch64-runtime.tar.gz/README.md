# Janus 一键部署（aarch64 版）

这是从 `wildfire_janus` 镜像提取的完整运行环境，**不需要 Docker，也不依赖其他任何软件**，
配置文件已全部内置，**无需挪动任何文件**。跟着下面的步骤操作即可。

---

## 一、解压（1 步）

把本压缩包上传到服务器，然后解压到 `/var/janus`（**注意：一定要解压到 `/var/janus` 目录里面**）：

```bash
mkdir -p /var/janus && tar xzf wf-janus-linux-aarch64-runtime.tar.gz -C /var/janus
```

> ⚠️ 不要写成 `cd /var && tar xzf ...`，那样会把 `usr/`、`lib/`、`opt/` 错解压到
> `/var/usr/`、`/var/lib/`、`/var/opt/` 下面，程序会找不到库。

解压后目录结构（自动就位，无需手动调整）：

```
/var/janus/
├── run-janus.sh                  # 启动脚本
├── janus/                        # janus 程序 + 配置文件
│   ├── bin/janus
│   ├── etc/janus/                # 配置文件（已内置，不用动）
│   └── lib/janus/                # 插件和传输
├── usr/  lib/  opt/              # 运行库（自动就位，不用动）
└── wf-janus.service              # 开机自启服务（可选，见第四节）
```

## 二、改配置（只需 1 个文件，只改 1 处）

配置文件已经内置在 `/var/janus/janus/etc/janus/`，**只需要改 MQTT 连接 IM 服务器的地址**：

```bash
vi /var/janus/janus/etc/janus/janus.transport.mqtt.jcfg
```

找到下面这行，把 `192.168.1.81` 改成你实际的 IM 服务器地址（其它不用动）：

```
im_host = "192.168.1.81"
```

> 如果 IM 服务器要求不同的 client_id 或 topic，也可顺手改 `client_id`、`subscribe_topic`、
> `publish_topic`，保持与 IM 服务端配置一致即可。

## 三、启动（1 步）

```bash
cd /var/janus && DOCKER_IP=服务器公网或内网IP ./run-janus.sh
```

- `DOCKER_IP` 填这台服务器的 IP（等价于以前 Docker 里的 `--nat-1-1=${DOCKER_IP}`）
- 看到下面输出就说明成功了：

```
Loading plugin 'libjanus_videoroom.so'...
JANUS VideoRoom plugin initialized!
Loading transport plugin 'libjanus_mqtt.so'...
```

## 四、开机自启（可选但推荐）

包内已经带好 systemd 服务文件，两步搞定：

```bash
# 1. 复制服务文件，并修改 DOCKER_IP 为服务器 IP
cp /var/janus/wf-janus.service /etc/systemd/system/
vi /etc/systemd/system/wf-janus.service     # 把 DOCKER_IP= 后面改成你的服务器IP

# 2. 启动并设置开机自启
systemctl daemon-reload
systemctl enable --now wf-janus

# 查看状态 / 日志
systemctl status wf-janus
journalctl -u wf-janus -f
```

> 用 systemd 启动后，以后就不用手动运行 `./run-janus.sh` 了；
> 临时手动运行和 systemd 不要同时开，二选一。

## 五、常用命令

| 操作 | 命令 |
|---|---|
| 前台启动 | `cd /var/janus && DOCKER_IP=IP ./run-janus.sh` |
| 停止 systemd 服务 | `systemctl stop wf-janus` |
| 重启服务 | `systemctl restart wf-janus` |
| 看实时日志 | `journalctl -u wf-janus -f` |
| 查版本 | `/var/janus/janus/bin/janus --version` |

## 六、防火墙端口

只需要放行 UDP 端口：

| 端口 | 用途 |
|---|---|
| 20000-40000/udp | RTP/RTCP 媒体端口（**必须放行**） |

MQTT 走 IM 服务器中转，不需要对外开端口。

## 七、常见问题

| 问题 | 原因 | 解决 |
|---|---|---|
| 启动报 `Couldn't access plugins folder` | 解压位置不对 | 确认解压到了 `/var/janus` 目录里面 |
| 启动报 `connect to server ... error` | IM 服务器连不上 | 检查 `im_host` 是否改对、网络是否通 |
| 报 `No such file or directory` | 直接执行了二进制 | 必须用 `./run-janus.sh` 启动 |
| 端口不通 | 防火墙没放行 | 放行 20000-40000/udp |
