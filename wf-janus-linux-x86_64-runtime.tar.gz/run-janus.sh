#!/bin/sh
# Janus 自包含运行时启动脚本（打包时按架构自动替换 ld-musl-x86_64.so.1）
#
# 约定部署位置：/var/janus （tarball 解压到 /var/janus）
#   /var/janus/janus/bin/janus           janus 主程序
#   /var/janus/janus/etc/janus/          配置文件（janus.jcfg 等）
#   /var/janus/janus/lib/janus/plugins   videoroom 插件
#   /var/janus/janus/lib/janus/transports mqtt 传输
#   /var/janus/usr/local/lib             libnice/libusrsctp/libpaho
#   /var/janus/lib                       musl 加载器 + openssl 等
#   /var/janus/usr/lib                   glib/jansson/libconfig 等
#
# 因为 janus 编译时 --prefix=/var/janus/janus，配置里的默认路径
# （plugins_folder/transports_folder/configs_folder）与上述布局天然一致，
# 配置文件无需任何修改。
#
# 用法：
#   DOCKER_IP=服务器IP ./run-janus.sh                 # 等价于 --nat-1-1=${DOCKER_IP}
#   JANUS_CONF_DIR=/etc/janus ./run-janus.sh          # 配置文件放到其它目录（可选）
#   ./run-janus.sh --debug-level=6                    # 额外 janus 参数

ROOT="$(cd "$(dirname "$0")" && pwd)"
export LD_LIBRARY_PATH="$ROOT/usr/local/lib:$ROOT/lib:$ROOT/usr/lib"
LOADER="$ROOT/lib/ld-musl-x86_64.so.1"
BIN="$ROOT/janus/bin/janus"

# 配置文件目录：默认 /var/janus/janus/etc/janus（与编译默认一致），可用 JANUS_CONF_DIR 覆盖
CONF_DIR="${JANUS_CONF_DIR:-$ROOT/janus/etc/janus}"

ARGS="-F $CONF_DIR"
if [ -n "$DOCKER_IP" ]; then
    ARGS="$ARGS --nat-1-1=$DOCKER_IP"
fi

exec "$LOADER" --library-path "$LD_LIBRARY_PATH" "$BIN" $ARGS "$@"
